/*
⚠️ PERINGATAN:
Script ini **TIDAK BOLEH DIPERJUALBELIKAN** dalam bentuk apa pun!

╔══════════════════════════════════════════════╗
║                🛠️ INFORMASI SCRIPT           ║
╠══════════════════════════════════════════════╣
║ 📦 Version   : 4.2.6
║ 👨‍💻 Developer  : Azhari Creative              ║
║ 🌐 Website    : https://autoresbot.com       ║
║ 💻 GitHub  : github.com/autoresbot/resbot-md ║
╚══════════════════════════════════════════════╝

📌 Mulai 11 April 2025,
Script **Autoresbot** resmi menjadi **Open Source** dan dapat digunakan secara gratis:
🔗 https://autoresbot.com
*/

const mess = {
    game: {
        isPlaying   : "⚠️ _Permainan sedang berlangsung._ Ketik *nyerah* untuk mengakhiri permainan.",
        isGroup     : "⚠️ _Permainan hanya bisa dimainkan di grup_",
        isStop      : "⚠️ _Fitur game dimatikan di grub ini_",
    },
    general : {
        isOwner     : ' _*PERINTAH INI KHUSUS SANG RAJA*_',
        isPremium   : ' _*MAKANYA PREMIUM HAHAHAHA*_',
        isAdmin     : ' _*PERINTAH INI KHUSUS ADMIN BOKEP*_',
        isGroup     : " _HAHAHA MAKANYA SEWA BOT, BIAR BISA DI PAKE FITUR INI*_",
        limit       : " _*HAHAHA LIMIT LU HABIS KASIAN*_",
        success     : " _*DONE*_",
        isBlocked   : " _*SI JELEK SEDANG DI BLOCK*_", // kalau block seluruhnya
        isBaned     : " _*MAKANYA MANDI BIAR GA DI BAN BOT*_", // kalau ban hanya grub itu saja
        fiturBlocked: " _*MAKANYA JANGAN RUSUH DI BAN KAN FITUR BOT*_",
    },
    action : {
        grub_open   : '_*WAKTUNYA KIRIM BOKEP*_',
        grub_close  : '_*YAHH ADMIN STOCK BOKEP NYA SUDAH HABIS, TUTUP DULU YA*_',
        user_kick   : ' _*ANAK HARAM SUDAH BERHASIL DI KICK*_',
        mute        : '_*ADMIN SOK KERAS MUTE BOT*_',
        unmute      : '_*NAH GITU UNMUTE BOT*_',
        resetgc     : '_*LINK BOKEP BERHASIL DI RESET*_',
    },
    handler : { // kosongkan jika tidak menggunakan notif = ''
        badword_warning : '⚠️ _*BADWORD TERDETEKSI*_ (@detectword)\n\n@sender _telah diperingati_ (@warning/@totalwarning)',
        badword_block   : '⛔ @sender _Telah diblokir karena mengirim *BADWORD* secara berulang. (@detectword) Hubungi owner jika ada pertanyaan._',
        antiedit        : '⚠️ _*ANTI EDIT DETECTED*_\n\n_Pesan Sebelumnya_ : @oldMessage',
        antidelete      : '⚠️ _*ANTI DELETE DETECTED*_\n\n_Pengirim_ : @sender \n_Pesan Sebelumnya_ : @text',
        antispamchat    : '⚠️ @sender _Jangan spam, ini peringatan ke-@warning dari @totalwarning._',
        antispamchat2   : '⛔ @sender _Telah diblokir karena melakukan spam secara berulang. Hubungi owner jika ada pertanyaan._',
        antivirtex      : '⚠️ @sender _Terdeteksi Mengirim Virtex._',
        antitagsw       : '⚠️ @sender _Terdeteksi Tag Sw di grub ini_',
        antibot         : '⚠️ @sender _Terdeteksi Adalah Bot_',
        afk             : '🚫 *Jangan tag dia!*\n\n❏ _@sender sedang AFK sejak *@durasi*_@alasan',
        afk_message     : '🕊️ @sender telah kembali dari AFK sejak _*@durasi*_.@alasan',
        sewa_notif      : '⚠️ _*Peringatan!*_\n\n_Masa Sewabot :_ @date',
        sewa_out        : `❌ _*Masa SewaBOT Telah Habis*_\n_Bot akan keluar otomatis_\n\nTerima kasih sudah menggunakan layanan sewa autoresbot.\n\n*Nomor Owner*\nwa.me/@ownernumber`
    },
    game_handler        : {
        menyerah        : 'Yahh Menyerah\nJawaban: @answer\n\nIngin bermain? Ketik *@command*',
        waktu_habis     : '⏳ Waktu habis! Jawabannya : @answer',
        tebak_angka     : '🎉 Selamat! Tebakan Anda benar. Anda mendapatkan @hadiah Money.',
        tebak_bendera   : '🎉 Selamat! Tebakan Anda benar. Anda mendapatkan @hadiah Money.',
        tebak_gambar    : '🎉 Selamat! Tebakan Anda benar. Anda mendapatkan @hadiah Money.',
        tebak_hewan     : '🎉 Selamat! Tebakan Anda benar. Anda mendapatkan @hadiah Money.',
        tebak_kalimat   : '🎉 Selamat! Tebakan Anda benar. Anda mendapatkan @hadiah Money.',
        tebak_kata      : '🎉 Selamat! Tebakan Anda benar. Anda mendapatkan @hadiah Money.',
        tebak_lagu      : '🎉 Selamat! Tebakan Anda benar. Anda mendapatkan @hadiah Money.',
        tebak_lirik     : '🎉 Selamat! Tebakan Anda benar. Anda mendapatkan @hadiah Money.',
    }
};

// Variable
global.group = {};
global.group.variable = `
☍ @name
☍ @date
☍ @day
☍ @desc
☍ @group
☍ @greeting
☍ @size
☍ @time`;

module.exports = mess;