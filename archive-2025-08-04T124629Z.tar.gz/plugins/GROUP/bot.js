async function handle(sock, messageInfo) {
    const { remoteJid, isGroup, message } = messageInfo;
    if (!isGroup) return; // Only Grub

    await sock.sendMessage(
        remoteJid,
        { text: `_*ADA APA KETUA?MAU SEWA BOT ATAU BIKIN BOT? PM OWNER*_` },
        { quoted: message }
    );
}

module.exports = {
    handle,
    Commands    : ["bot"],
    OnlyPremium : false,
    OnlyOwner   : false
};
